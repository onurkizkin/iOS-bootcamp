//
//  KisilerCevap.swift
//  KisilerUygulaması
//
//  Created by Onur Kızkın on 2.01.2024.
//

import Foundation

class KisilerCevap : Codable {
    
    var kisiler: [Kisiler]?
    var success: Int?
}
