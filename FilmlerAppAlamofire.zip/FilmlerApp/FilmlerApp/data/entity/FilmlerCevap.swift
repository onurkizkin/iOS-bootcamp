//
//  FilmlerCevap.swift
//  FilmlerApp
//
//  Created by Onur Kızkın on 2.01.2024.
//

import Foundation

class FilmlerCevap : Codable {
    var filmler: [Filmler]?
    var success: Int?
}
